import { observer } from "mobx-react-lite";
import state from "../../stores/state";
import {
  getComponentSublayers,
  getExtentAcrossSublayers,
} from "../../utils/buildingLayer";
import { applyFocusArea, clearFocusArea } from "../../utils/focusArea";
import { buildingConfig } from "../../config";

/**
 * Nivel 2 — Informative: Focus Area.
 * Lista los pisos disponibles (poblados por SceneView/index.tsx al cargar
 * la vista) y, al seleccionar uno, atenúa el resto del edificio usando el
 * efecto nativo FocusArea del SDK en vez de ocultar/filtrar capas.
 *
 * No se renderiza nada hasta que SceneView detecta una BuildingSceneLayer
 * en la escena (state.buildingLayer), así que en una escena sin BIM este
 * panel simplemente no aparece.
 */
const FocusAreaPanel = observer(() => {
  if (!state.buildingLayer) return null;

  const handleSelectLevel = async (level: string) => {
    if (!state.sceneView || !state.buildingLayer) return;

    const sublayers = getComponentSublayers(state.buildingLayer);
    const extent = await getExtentAcrossSublayers(
      sublayers,
      buildingConfig.levelField,
      level
    );
    if (!extent) return;

    applyFocusArea(state.sceneView, extent, "dark");
    state.setFocusedLevel(level);
  };

  const handleClear = () => {
    if (!state.sceneView) return;
    clearFocusArea(state.sceneView);
    state.setFocusedLevel(null);
  };

  return (
    <calcite-panel
      heading="Focus Area"
      description="Selecciona un piso para resaltarlo"
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "0.5rem",
          padding: "0.75rem",
        }}
      >
        {state.availableLevels.length === 0 && (
          <calcite-notice open kind="neutral" scale="s">
            <div slot="message">
              No se encontró el campo "{buildingConfig.levelField}" en la
              capa. Ajusta buildingConfig.levelField en config.ts.
            </div>
          </calcite-notice>
        )}
        {state.availableLevels.map((level) => (
          <calcite-button
            key={level}
            appearance={state.focusedLevel === level ? "solid" : "outline"}
            width="full"
            onClick={() => handleSelectLevel(level)}
          >
            {level}
          </calcite-button>
        ))}
      </div>
      <calcite-button
        slot="footer"
        width="full"
        appearance="outline"
        kind="neutral"
        disabled={!state.focusedLevel}
        onClick={handleClear}
      >
        Quitar selección
      </calcite-button>
    </calcite-panel>
  );
});

export default FocusAreaPanel;
