/* Copyright 2025 Esri
 *
 * Licensed under the Apache License Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import React, {StrictMode} from 'react';
import { createRoot } from 'react-dom/client';
import esriConfig from '@arcgis/core/config';
import './main.css';
import '@esri/calcite-components/main.css';
import '@arcgis/map-components/main.css';
import App from './components/App';
import { portalUrl } from './config';

esriConfig.portalUrl = portalUrl;

const root = createRoot(document.getElementById('root') as HTMLElement);

root.render(
    <StrictMode>
        <App></App>
    </StrictMode>
);